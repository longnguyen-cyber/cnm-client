module.exports = {
    twin: {
        preset: "styled-components",
        config: "tailwind.config.js",
    },
};
