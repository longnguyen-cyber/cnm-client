module.exports = {
    tabWidth: 4,
    printWidth: 80,
    endOfLine: "auto",
    arrowParens: "avoid",
    trailingComma: "all",
    semi: true,
    useTabs: false,
    singleQuote: false,
    bracketSpacing: true,
};
