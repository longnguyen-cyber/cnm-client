import styled from "styled-components";
import { Text } from "zmp-ui";

const SectionTitle = styled(Text.Title)``;

export default SectionTitle;
