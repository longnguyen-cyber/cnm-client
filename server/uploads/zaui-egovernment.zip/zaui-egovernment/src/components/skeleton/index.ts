export { default as SearchItemSkeleton } from "./SearchItemSkeleton";
export { default as OAItemSkeleton } from "./OAItemSkeleton";
export { default as TextItemSkeleton } from "./TextSketeton";
export { default as NewsItemSkeleton } from "./NewsItemSkeleton";
export { default as InformationGuideItemSkeleton } from "./InformationGuideItemSkeleton";
export { default as FeedbackItemSkeleton } from "./FeedbackItemSkeleton";
export { default as AvatarSkeleton } from "./AvatarSkeleton";
