export const UNAUTHORIZED = -115;
export const RATE_LIMIT_CODE = {
    code: -117,
    message: "Bạn đã đạt giới hạn tìm kiếm trong ngày",
};
