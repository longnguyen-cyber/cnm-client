export { default as GuidelinesPage } from "./GuidelinesPage";
