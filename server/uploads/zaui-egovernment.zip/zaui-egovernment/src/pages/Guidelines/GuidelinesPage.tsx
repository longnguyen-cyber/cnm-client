import React from "react";
import PageLayout from "@components/layout/PageLayout";

const GuidelinesPage = () => <PageLayout title="Thông tin - hướng dẫn" />;
export default GuidelinesPage;
