export { default as AppointmentScheduleResultPage } from "./AppointmentScheduleResultPage";
