export { default as CreateFeedbackPage } from "./CreateFeedbackPage";
export { default as FeedbackDetailPage } from "./FeedbackDetailPage";
export { default as FeedbackPage } from "./FeedbackPage";
