export { default as InformationGuidePage } from "./InformationGuidePage";
