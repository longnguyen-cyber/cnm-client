export { default as SearchPage } from "./SearchPage";
